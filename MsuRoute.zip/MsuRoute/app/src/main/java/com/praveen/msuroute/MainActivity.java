package com.praveen.msuroute;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {


    MaterialButton directionButton;
    private final double MSU_LATITUDE = 40.8666;
    private final double MSU_LONGITUDE = 74.1976;
    private final String MAP_PACKAGE = "com.google.android.apps.maps";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        directionButton = findViewById(R.id.directionButton);
        directionButton.setOnClickListener(view -> {

            Uri gmmIntentUri = Uri.parse("google.navigation:q=Montclair+State+University,+Normal+Ave+Montclair,+NJ");
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
            mapIntent.setPackage("com.google.android.apps.maps");

            try {
                if (mapIntent.resolveActivity(this.getPackageManager()) != null) {
                    startActivity(mapIntent);
                }
            } catch (NullPointerException e) {
                View rootV = findViewById(R.id.root);
                Snackbar snackBar = Snackbar.make(this, rootV, "Something went wrong...",
                        Snackbar.LENGTH_SHORT);
                snackBar.show();
            }
        });
    }
}